"""
app.py
------
Gradio UI for code_assistant_rag.

Tabs:
  1. Ingest Codebase  – upload a .zip of your project, auto-extract and ingest
  2. Ask the Codebase – chat with indexed codebase, see retrieved context + eval scores
"""

import os
import shutil
import sys
import tempfile
import threading
import zipfile
from io import StringIO

import gradio as gr
from dotenv import load_dotenv

from answer import answer_question
from ingest import ingest

load_dotenv(override=True)


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def format_context(chunks) -> str:
    if not chunks:
        return "*No context retrieved.*"
    lines = ["## 📂 Retrieved Chunks\n"]
    for chunk in chunks:
        source = chunk.metadata.get("source", "unknown")
        lines.append(f"---\n**`{source}`**\n\n{chunk.page_content}\n")
    return "\n".join(lines)


def format_eval(eval_result) -> str:
    if eval_result is None:
        return "*Evaluation will appear here after your first question.*"

    def bar(score: float) -> str:
        filled = round(score)
        return "🟩" * filled + "⬜" * (5 - filled)

    overall_color = (
        "🟢" if eval_result.overall >= 4.0
        else "🟡" if eval_result.overall >= 3.0
        else "🔴"
    )

    return f"""## {overall_color} Answer Quality

| Dimension | Score | |
|---|---|---|
| 🎯 Accuracy | {eval_result.accuracy:.1f} / 5 | {bar(eval_result.accuracy)} |
| 🔍 Relevance | {eval_result.relevance:.1f} / 5 | {bar(eval_result.relevance)} |
| 📋 Completeness | {eval_result.completeness:.1f} / 5 | {bar(eval_result.completeness)} |
| **Overall** | **{eval_result.overall:.1f} / 5** | {bar(eval_result.overall)} |

**Reasoning:** *{eval_result.reasoning}*
"""


# ══════════════════════════════════════════════════════════════════════════════
# Tab 1 — Ingest
# ══════════════════════════════════════════════════════════════════════════════

def run_ingest(zip_file, reset: bool):
    """Extract zip, run ingestion pipeline, stream log to UI."""
    if zip_file is None:
        yield "⚠️ Please upload a .zip file of your project first."
        return

    tmp_dir = tempfile.mkdtemp(prefix="code_rag_")

    try:
        yield "📦 Extracting zip file...\n"

        with zipfile.ZipFile(zip_file, "r") as zf:
            zf.extractall(tmp_dir)

        # If zip has a single top-level folder inside, use that as root
        contents = os.listdir(tmp_dir)
        if len(contents) == 1 and os.path.isdir(os.path.join(tmp_dir, contents[0])):
            repo_path = os.path.join(tmp_dir, contents[0])
        else:
            repo_path = tmp_dir

        yield f"✅ Extracted successfully\n🔍 Scanning: `{repo_path}`...\n\n"

        output_buffer = StringIO()
        original_stdout = sys.stdout

        def run():
            sys.stdout = output_buffer
            try:
                ingest(repo_path, reset=reset)
            except Exception as e:
                output_buffer.write(f"\n❌ Error: {e}\n")
            finally:
                sys.stdout = original_stdout

        import time
        thread = threading.Thread(target=run)
        thread.start()

        while thread.is_alive():
            time.sleep(0.5)
            current = output_buffer.getvalue()
            if current:
                yield f"```\n{current}\n```"

        thread.join()
        final = output_buffer.getvalue()
        yield f"```\n{final}\n```\n\n✅ **Ingestion complete!** Switch to the **💬 Ask** tab to start querying."

    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


# ══════════════════════════════════════════════════════════════════════════════
# Tab 2 — Chat
# ══════════════════════════════════════════════════════════════════════════════

def put_message_in_chatbot(message: str, history: list):
    return "", history + [{"role": "user", "content": message}]


def chat(history: list):
    if not history:
        return history, "*No context yet.*", "*No evaluation yet.*"

    last_message = history[-1]["content"]
    prior = history[:-1]

    answer, chunks, eval_result = answer_question(last_message, prior)
    history.append({"role": "assistant", "content": answer})

    return history, format_context(chunks), format_eval(eval_result)


# ══════════════════════════════════════════════════════════════════════════════
# UI
# ══════════════════════════════════════════════════════════════════════════════

def main():
    theme = gr.themes.Base(
        primary_hue="emerald",
        secondary_hue="slate",
        neutral_hue="slate",
    ).set(
        body_background_fill="#0f1117",
        body_background_fill_dark="#0f1117",
        block_background_fill="#1a1d27",
        block_background_fill_dark="#1a1d27",
        block_border_color="#2d3148",
        block_border_color_dark="#2d3148",
        block_label_text_color="#a0a8c0",
        block_label_text_color_dark="#a0a8c0",
        input_background_fill="#12151f",
        input_background_fill_dark="#12151f",
        input_border_color="#2d3148",
        input_border_color_dark="#2d3148",
        button_primary_background_fill="#6366f1",
        button_primary_background_fill_dark="#6366f1",
        button_primary_background_fill_hover="#4f46e5",
        button_primary_background_fill_hover_dark="#4f46e5",
        button_primary_text_color="white",
        button_primary_text_color_dark="white",
        body_text_color="#e2e8f0",
        body_text_color_dark="#e2e8f0",
        body_text_color_subdued="#94a3b8",
        body_text_color_subdued_dark="#94a3b8",
    )

    css = """
    .gradio-container { max-width: 1400px !important; }
    .tab-nav button { font-size: 1rem !important; padding: 10px 20px !important; }
    .tab-nav button.selected { border-bottom: 2px solid #6366f1 !important; color: #6366f1 !important; }
    footer { display: none !important; }
    """

    with gr.Blocks(title="Code Assistant RAG", theme=theme, css=css) as ui:

        # ── Header ────────────────────────────────────────────────────────────
        gr.HTML("""
        <div style="padding: 28px 0 18px 0; border-bottom: 1px solid #2d3148; margin-bottom: 8px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 6px;">
                <span style="font-size: 2rem;">🤖</span>
                <h1 style="font-size: 2rem; font-weight: 700; color: #e2e8f0; margin: 0;">
                    Code Assistant RAG
                </h1>
            </div>
            <p style="color: #94a3b8; font-size: 1rem; margin: 0;">
                Ingest any codebase. Ask anything about it. &nbsp;·&nbsp;
                <span style="color: #6366f1;">GPT-4.1</span> &nbsp;·&nbsp;
                <span style="color: #6366f1;">ChromaDB</span> &nbsp;·&nbsp;
                <span style="color: #6366f1;">text-embedding-3-large</span>
            </p>
        </div>
        """)

        with gr.Tabs():

            # ── TAB 1: INGEST ─────────────────────────────────────────────────
            with gr.Tab("📁  Ingest Codebase"):

                gr.HTML("""
                <div style="padding: 20px 0 8px 0;">
                    <h2 style="font-size: 1.4rem; font-weight: 600; color: #e2e8f0; margin: 0 0 8px 0;">
                        1. Add your project
                    </h2>
                    <p style="color: #94a3b8; margin: 0 0 6px 0;">
                        Upload your project as a <code style="color:#6366f1;">.zip</code> file.
                        The pipeline will scan every source file, split it into semantic chunks using an LLM,
                        generate embeddings, and store everything in a local ChromaDB vector database.
                    </p>
                    <p style="color: #64748b; font-size: 0.875rem; margin: 0;">
                        <strong style="color:#94a3b8;">Supported:</strong>
                        .py .js .ts .jsx .tsx .md .json .yaml .html .css .sh .sql and more &nbsp;·&nbsp;
                        <strong style="color:#94a3b8;">Auto-ignored:</strong>
                        .git &nbsp; node_modules &nbsp; .venv &nbsp; __pycache__ &nbsp; build &nbsp; dist
                    </p>
                </div>
                """)

                with gr.Row(equal_height=True):
                    with gr.Column(scale=3):
                        zip_input = gr.File(
                            label="📦 Upload Project ZIP",
                            file_types=[".zip"],
                            type="filepath",
                            height=160,
                        )
                    with gr.Column(scale=1):
                        gr.HTML("""
                        <div style="padding: 16px 0 8px 0;">
                            <h3 style="font-size: 1rem; color: #e2e8f0; margin: 0 0 12px 0;">2. Options</h3>
                        </div>
                        """)
                        reset_checkbox = gr.Checkbox(
                            label="🗑️ Reset existing index",
                            value=False,
                            info="Wipe ChromaDB before ingesting (use when re-indexing a project)",
                        )

                ingest_button = gr.Button(
                    "🚀  Start Ingestion", variant="primary", size="lg"
                )

                gr.HTML("""
                <div style="padding: 16px 0 4px 0;">
                    <h3 style="font-size: 1rem; color: #e2e8f0; margin: 0 0 4px 0;">3. Ingestion Log</h3>
                </div>
                """)

                ingest_output = gr.Markdown(
                    value="*Upload a `.zip` and click **Start Ingestion** to begin.*",
                    container=True,
                    height=300,
                )

                ingest_button.click(
                    fn=run_ingest,
                    inputs=[zip_input, reset_checkbox],
                    outputs=ingest_output,
                )

            # ── TAB 2: ASK ────────────────────────────────────────────────────
            with gr.Tab("💬  Ask the Codebase"):

                gr.HTML("""
                <div style="padding: 20px 0 12px 0;">
                    <h2 style="font-size: 1.4rem; font-weight: 600; color: #e2e8f0; margin: 0 0 6px 0;">
                        Ask anything about your indexed project
                    </h2>
                    <p style="color: #64748b; font-size: 0.9rem; margin: 0;">
                        Try: &nbsp;
                        <em>"Where is the function that creates embeddings?"</em> &nbsp;·&nbsp;
                        <em>"How does the retry logic work?"</em> &nbsp;·&nbsp;
                        <em>"What files handle database connections?"</em>
                    </p>
                </div>
                """)

                with gr.Row():

                    # Left — chat
                    with gr.Column(scale=2):
                        chatbot = gr.Chatbot(
                            label="💬 Conversation",
                            height=500,
                            type="messages",
                            show_copy_button=True,
                            placeholder="Ask about any function, module, or concept in your codebase.",
                        )
                        with gr.Row():
                            message_input = gr.Textbox(
                                placeholder="e.g. Where is the rerank function and how does it work?",
                                show_label=False,
                                lines=2,
                                scale=4,
                            )
                            send_btn = gr.Button("Send ↩", variant="primary", scale=1)

                    # Right — eval + context
                    with gr.Column(scale=1):
                        eval_panel = gr.Markdown(
                            value="*Answer quality scores will appear here.*",
                            label="📊 Answer Quality",
                            container=True,
                            height=220,
                        )
                        context_panel = gr.Markdown(
                            value="*Retrieved code chunks will appear here.*",
                            label="📂 Retrieved Context",
                            container=True,
                            height=310,
                        )

                message_input.submit(
                    fn=put_message_in_chatbot,
                    inputs=[message_input, chatbot],
                    outputs=[message_input, chatbot],
                ).then(
                    fn=chat,
                    inputs=chatbot,
                    outputs=[chatbot, context_panel, eval_panel],
                )

                send_btn.click(
                    fn=put_message_in_chatbot,
                    inputs=[message_input, chatbot],
                    outputs=[message_input, chatbot],
                ).then(
                    fn=chat,
                    inputs=chatbot,
                    outputs=[chatbot, context_panel, eval_panel],
                )

    ui.launch(inbrowser=True)


if __name__ == "__main__":
    main()